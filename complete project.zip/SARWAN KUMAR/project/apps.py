from flask import Flask, request, jsonify
import joblib
from flask_cors import CORS

app = Flask(__name__)

# Enable CORS to handle cross-origin requests from the frontend
CORS(app)

# Load the model once at startup
model = joblib.load('lr_best_model.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from the request
        data = request.json.get('data')
        print("Received data:", data)

        if not data or len(data) != 12:
            return jsonify({"error": "Invalid input data"}), 400

        # Ensure data is in the correct format (reshape if needed)
        prediction = model.predict([data])
        print("Prediction:", prediction)
        
        # Return prediction as JSON
        return jsonify({'prediction': int(prediction[0])})
    
    except Exception as e:
        print("Prediction error:", e)
        return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(debug=True)
